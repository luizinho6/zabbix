<?php

$rows = [];
$rows[] = [
	_('Host'),
	_('Name'),
	_('Problems'),
	_('Ok')
];

foreach ($data['triggers'] as $trigger) {
	$availability = calculateAvailability($trigger['triggerid'], $data['filter']['timeline']['from_ts'],
		$data['filter']['timeline']['to_ts']
	);

	$rows[] = [
		$trigger['host_name'],
		$trigger['description'],
		($availability['true'] < 0.00005)
			? ''
			: sprintf('%.4f%%', $availability['true']),
		($availability['false'] < 0.00005)
			? ''
			: sprintf('%.4f%%', $availability['false'])
	];
}

echo zbx_toCSV($rows);