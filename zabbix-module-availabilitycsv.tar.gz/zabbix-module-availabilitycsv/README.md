# Module: Availability report export

### Overview

The *Availability report export* module allows to export availability data to a CSV file. The module adds:

-   an *Export to CSV* button in Zabbix frontend, at the top right corner of the *Availability report* page;
-   the ability to export availability data using an HTTP endpoint.

### Installation

1\. Download the [ZIP file](#add-link-here).

2\. Extract the ZIP file contents.

3\. Move the extracted `zabbix-module-availabilitycsv` directory to the `/zabbix/ui/modules` directory.

4\. Log into Zabbix frontend, navigate to *Administration* → *General* → Modules, and click the *Scan directory* button at the top right corner of the page.

5\. Locate the module in the modules list and click the "Disabled" hyperlink to change the module's status from "Disabled" to "Enabled".

### Use

##### Zabbix frontend

1\. Log into Zabbix frontend.

2\. Navigate to *Reports → *Availability report*.

3\. If necessary, use filtering options to filter the availability data displayed.
For the available filtering options, see [*Availability report*](https://www.zabbix.com/documentation/7.0/en/manual/web_interface/frontend_sections/reports/availability#using-filter) in Zabbix Manual.

4\. Click the *Export to CSV* button at the top right corner of the *Availability report* page to export the availability data to a CSV file.
The CSV file will be saved in the default downloads directory specified in the browser settings.

##### HTTP endpoint

1\. Log into Zabbix frontend by making an HTTP POST request to the `index.php` file of your Zabbix frontend installation.

```bash
curl --cookie-jar auth.cookie --data "name=Admin&password=zabbix&enter=1" -X POST https://example.com/zabbix/index.php
```

-   `--cookie-jar auth.cookie` specifies the file (`auth.cookie`) that will store the authentication cookie received in the response.
    The `auth.cookie` file will be created in the current directory upon receiving the response and will store the cookie used for maintaining the user session.

-   `--data "name=Admin&password=zabbix&enter=1"` specifies the data sent in the request and includes values used for authentication;
    replace `Admin` and `zabbix` with your credentials.

-   `-X POST https://example.com/zabbix/index.php` specifies the request type (`POST`) and the URL to which the request is sent;
    replace the URL with your URL.

2\. Export the availability data to a CSV file (to the current directory).

```bash
curl --cookie auth.cookie --output zbx_availability.csv https://example.com/zabbix/zabbix.php?action=availability.export.csv
```

-   `--cookie auth.cookie` specifies the file (`auth.cookie`) to use for authentication.

-   `--output zbx_availability.csv` specifies the CSV file (`report.csv`) that will store the availability data included in the response from the URL.

-   `https://example.com/zabbix/zabbix.php?action=availability.export.csv` specifies the URL to which the request is sent.
    Replace the URL with your URL, and, if necessary, specify filtering options (as query parameters in the URL) to filter the availability data to be exported.

Note that you can set the desired filter in Zabbix frontend, click *Apply*, and then copy the URL.

The following query parameters are available:

| Parameter                  | Description                                                                                                                                                                               |
|----------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `mode`                     | Report mode: 0 - filter triggers by hosts; 1 - filter triggers by trigger template.                                                                                                       |
| `from`                     | Report time period start in absolute (`YYYY-MM-DD hh:mm:ss`) or relative time syntax (`now`, `now/d`, `now/w-1w`, etc.).                                                                  |
| `to`                       | Report time period end in absolute (`YYYY-MM-DD hh:mm:ss`) or relative time syntax (`now`, `now/d`, `now/w-1w`, etc.).                                                                    |
| `filter_set`               | To apply the filter, this parameter must be set to `1`.                                                                                                                                   |

| Parameter if `mode=0`      | Description                                                                                                                                                                               |
|----------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `filter_groups[]`          | Filter triggers by hosts belonging to the specified host groups. To specify multiple host groups, add a query parameter for each host group (e.g. `filter_groups[]=2&filter_groups[]=4`). |
| `filter_hostids[]`         | Filter triggers belonging to the specified hosts. To specify multiple hosts, add a query parameter for each host (e.g. `filter_hostids[]=10084&filter_hostids[]=10086`).                  |

| Parameter if `mode=1`      | Description                                                                                                                                                                               |
|----------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `filter_groupid`           | Filter triggers by templates belonging to the specified template group. To specify all template groups, set the query parameter value to `0`.                                             |
| `filter_templateid`        | Filter triggers belonging to the specified template. To specify all templates, set the query parameter value to `0`.                                                                      |
| `tpl_triggerid`            | Filter triggers by the specified trigger. To specify all triggers, set the query parameter value to `0`.                                                                                  |
| `hostgroupid`              | Filter triggers by hosts belonging to the specified host groups. To specify all host groups, set the query parameter value to `0`.                                                        |

For example, to export the availability data from the last 1 hour for the "Zabbix server" host, send the following request:

```bash
curl --cookie auth.cookie --output zbx_availability.csv https://example.com/zabbix/zabbix.php?action=availability.export.csv&mode=0&from=now-1h&to=now&filter_groups[]=4&filter_hostids[]=10084&filter_set=1
```

3\. Log out from Zabbix frontend.

```bash
curl --cookie auth.cookie https://example.com/zabbix/index.php?reconnect=1
```

### Export result

The exported CSV file will contain availability data based on the filter set.

```csv
"Host","Name","Problems","Ok"
"Zabbix server","/: Disk space is critically low","","100.0000%"
"Zabbix server","/: Disk space is low","","100.0000%"
"Zabbix server","/: Filesystem became read-only","","100.0000%"
"Zabbix server","/: Running out of free inodes","","100.0000%"
"Zabbix server","/: Running out of free inodes","","100.0000%"
[...]
```
