<?php

namespace Modules\AvailabilityReportCsv\Actions;


use CWebUser;
use CController as CAction;
use CControllerResponseData;

class ExportCsv extends CAction {

	public function init() {
		if (method_exists($this, 'disableCsrfValidation')) {
			$this->disableCsrfValidation();
		}
		else {
			$this->disableSidValidation();
		}
	}

	protected function checkInput() {
		return true;
	}

	protected function checkPermissions() {
		return true;
	}

	public function doAction() {
		ob_start();
		CWebUser::$data['rows_per_page'] = PHP_INT_MAX;
		require __DIR__.'/zabbix/report2.php';
		ob_get_clean();

		$response = new CControllerResponseData([
			'triggers' => $triggers,
			'filter' => $data['filter']
		]);
		$response->setTitle(_('Availability report'));
		$response->setFileName('zbx_availability.csv');
		$this->setResponse($response);
	}
}
