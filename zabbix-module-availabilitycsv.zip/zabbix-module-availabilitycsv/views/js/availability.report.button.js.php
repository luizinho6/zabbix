<script>
const tmpl = document.createElement('div');

tmpl.innerHTML = `<?=
	(new CTag('li', true))->addItem(
		new CRedirectButton(_('Export to CSV'), (new CUrl('zabbix.php'))->setArgument('action', 'availability.export.csv'))
	)
?>`;
document.querySelector('.header-controls [name="mode"]').parentNode.append(...tmpl.childNodes);
</script>
