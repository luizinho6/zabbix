<?php

namespace Modules\AvailabilityReportCsv;

if (version_compare(ZABBIX_VERSION, '6.4.0', '>')) {
	class_exists('\Core\CModule', false) or class_alias('\Zabbix\Core\CModule', '\Core\CModule');
	class_exists('\CWidget', false) or class_alias('\CHtmlPage', '\CWidget');
}

use CLegacyAction;
use CController as CAction;
use Core\CModule as ModuleBase;

class Module extends ModuleBase {

	protected $append_js = false;

	public function init(): void {
	}

	/**
	 * Before action event handler.
	 *
	 * @param CAction $action    Current request handler object.
	 */
	public function onBeforeAction(CAction $action): void {
		if (is_a($action, CLegacyAction::class) && $action->getAction() === 'report2.php') {
			$this->append_js = true;
		}
	}

	/**
	 * For login/logout actions update user seession state in multiple databases.
	 */
	public function onTerminate(CAction $action): void {
		if (!$this->append_js) {
			return;
		}

		include __DIR__.'/views/js/availability.report.button.js.php';
	}
}
